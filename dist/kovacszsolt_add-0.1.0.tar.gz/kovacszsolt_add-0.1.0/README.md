# kovacszsolt_add

Egy egyszerű csomag, amely összead két számot.

## Használat

```python
from kovacszsolt_add import add

print(add(2, 3))  # 5

