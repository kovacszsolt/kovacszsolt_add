from setuptools import setup

setup(
    name='kovacszsolt_add',
    version='0.0.1',
    author='Te',
    author_email='te@pelda.com',
    description='Egy tesztcsomag GitHub Packages-hez',
    packages=['kovacszsolt_add'],
)
